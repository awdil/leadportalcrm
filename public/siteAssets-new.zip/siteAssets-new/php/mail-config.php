<?php 

// put your email address here
define('YOUR_EMAIL_ADDRESS', 'mail@themeinjection.com'); 
define('YOUR_COMPANY_NAME', 'Car|Rental Landing Page'); 

$mailchimpSupport 	= true; // set 'true' to activate mailchimp support

define('MAILCHIMP_API_KEY', 'b714582d55c439ece1f49cb8d167c4b9-us3');
define('MAILCHIMP_LIST_ID', 'f84fe4d84c');

